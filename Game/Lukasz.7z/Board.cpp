#include "Board.h"

#include <fstream>
#include <map>
#include <set>
#include <typeinfo>
#include <qset.h>
#include <ctime>
#include <cstdlib>

//PRIVATE:
int Board::outbreaksMarker = 0;
vector<int> Board::infectionRateMarker;

void Board::MedicIncoming()
{
	for (Disease& dis : diseases)
	{
		if (dis.Status() == DISCOVERED)
		{
			currentPlayer->TreatCity(&dis);
		}
	}
}

void Board::DiscardSpecialCard(string cardName)
{
	for (Player* play : players)
	{
		PlayerCard* card = play->FindCard(cardName);
		if (card != nullptr)
		{
			play->Discard(card);
			playerDiscarded.PutCard(card);
			break;
		}
	}
}

void Board::Infect(Card* card, int cubesCount)
{
	Disease* disease = FindDisease(card->GetColor());
	disease->diseaseAppearsIn(FindCity(card->GetName()), cubesCount);
	diseasesDiscarded.PutCard(card);
	mediator().moveCard(card, &(this->diseasesDiscarded));//tu moze chwila na zauwazenie, gdzie zmiana? bo wchodza po 2-4 szt.
}

void Board::PlayTheInfection(bool isSkipped)
{
	if (!isSkipped)
	{
		Card* card;
		for (int i = 0; i < infectionRateMarker[infectionRateMarker[0]]; ++i)
		{
			card = diseasesNew.takeCard();
			Infect(card, 1);
		}
	}
}
//PUBLIC:
City* Board::FindCity(string name) const
{
	for (City* city : Cities)
	{
		if (city->GetName() == name)
		{
			return city;
		}
	}
	return nullptr;
}

vector<City*> Board::GetStations() const
{
	return(Stations);
}

void Board::DiscoverCure()
{
	if (currentPlayer->GetRole() == ROLE_SCIENTIST)
	{
		mediator().playerMayDiscardCards(4, THISMETHOD(&Board::DiscoverCure_FinalStep)); //do poprawy  - brak parametru VECTOR<CARD*> cardsInColor
	}
	else
	{
		mediator().playerMayDiscardCards(5, THISMETHOD(&Board::DiscoverCure_FinalStep)); //do poprawy ;
	}
}

void Board::DiscoverCure_FinalStep(QVector<Card*> cardsRemoved)
{ 
	vector<Card*> cards = cardsRemoved.toStdVector();
	Disease* dis = FindDisease(cardsInColor[0]->GetColor());//wszystkie karty maja ten sam kolor - wczesniej.. wiec wez pierwsza z brzegu i sprawdz
	currentPlayer->DiscoverCure(cards, dis);
}

void Board::UseSpecial()
{
	ChooseSpecial();
}

GameResult Board::Pass()
{
	switch (gameStatus)
	{
	case IN_PROGRESS:
		try
		{
			Card* card;
			EpidemicCard* eCard;
			Mediator m = mediator();
			for (int j = 0; j < 2; ++j) //nie rozbijam ciagniecia kart na 2 pojedyncze rozdzielane uzyciem specjalnej
			{
				if (playerNew.IsEmpty())
				{
					throw string("No cards left !!!");
				}
				else
				{
					card = playerNew.takeCard();
					eCard = dynamic_cast<EpidemicCard*>(card);
					if (eCard != nullptr)
					{
						Card* dCard = diseasesNew.TakeBottom();
						Infect(dCard, 3);							//na podstawie karty zajmuje sie calym procesem infekowania
						diseasesNew.Rethrow(&diseasesDiscarded);
						InfectionIncrease();
						playerDiscarded.PutCard(card);
						m.moveCard(card, &(this->playerDiscarded));		//czy tak adres bedzie przekazany? czyli uzyskam pointer?
					}
					else
					{
						currentPlayer->EarnCard((PlayerCard*)card);
					}
				}
			}
			PlayTheInfection(skipInfecting); //ROZSZERZ CHOROBY
			skipInfecting = false;
			++currentPlayerNumber;
			movesLeft = 4;
		}
		catch (out_of_range except) //moze rzucac tez wartosc - typ przegranej?
		{
#pragma COMMENT("Koniec gry - mediator powinien tu cos zrobic")
			//mediator().;
			cout << endl << endl << except.what();
			gameStatus = FAILED;
		}
		catch (string error)
		{
			cout << endl << endl << error;
			gameStatus = FAILED;
		}
		break;
	}		
	/*if (gameStatus<0)
	{
		cout << "PORAZKA" << endl;
	}
	else
	{
		cout << "Wygrana !!!" << endl;
	}*/
	return gameStatus;
}

Disease* Board::FindDisease(DiseaseType ID)
{
	for (Disease &dis : diseases)
	{
		if (dis.getID() == ID)
		{
			return &dis;
		}
	}
	return nullptr;
}

void Board::Outbreak()
{
	outbreaksMarker++;
	mediator().increaseOutbreaksMarker();
	if (outbreaksMarker == 8)
	{
		throw out_of_range("FAILED due to outbreaks");
	}
}

void Board::InfectionIncrease()
{
	if (infectionRateMarker[0] < infectionRateMarker.size()-1)
	{
		/*cout << infectionRateMarker[0] << endl;						//DIAGNOSTYCZNIE
		cout << "number: " << infectionRateMarker[infectionRateMarker[0]] << endl;*/		//odczyt wlasciwej wartosci - sposob
		infectionRateMarker[0]++;
		mediator().increaseInfectionsMarker();
	}
}

int Board::GetInfectionRateMarker()
{
	return infectionRateMarker[infectionRateMarker[0]];
}

int Board::GetStatus() const
{
	return gameStatus;
}

bool IsEradicated(Disease& disease)	//lokalna funkcja dla ALL_OF
{
	return (disease.Status() == TREATED) || (disease.Status() == DISCOVERED);
}

vector<Decision> Board::IsAbleTo()
{
	currentPlayer = players[currentPlayerNumber%players.size()];
	vector<Decision> decisionsAvailable;
	if (movesLeft > 0)
	{
		currentCity = currentPlayer->GetPosition();
		cityCard = currentPlayer->FindCard(currentCity->GetName());
		decisionsAvailable.push_back(DEC_MOVE_SHORT);								//MOVE_SHORT
		if (currentPlayer->GetRole() == ROLE_DISPATCHER)							//MOVE_ANOTHER
		{
			decisionsAvailable.push_back(DEC_MOVE_ANOTHER);
		}
		for (PlayerCard* card : currentPlayer->SeeCards())							//MOVE_TO_CARD
		{
			if (card->GetName() != currentCity->GetName())
			{
				decisionsAvailable.push_back(DEC_MOVE_TO_CARD);
				break;
			}
		}
		if (cityCard != nullptr)													//MOVE_ENYWHERE
		{
			decisionsAvailable.push_back(DEC_MOVE_EVERYWHERE);
		}
		if (!(currentCity->IsStation()) && (currentPlayer->GetRole() == ROLE_OPERATIONSEXPERT || cityCard != nullptr))
		{
			decisionsAvailable.push_back(DEC_BUILD_STATION);						//BUILD_STATION
		}
		for (Disease dis : diseases)												//TREAT
		{
			if (currentCity->DiseaseCounter(dis.getID()) > 0)
			{
				decisionsAvailable.push_back(DEC_TREAT);
				break;
			}
		}
		isResearcher = false;
		anotherPlayersCityCard = nullptr;
		for (Player* play : players)				//wybierz graczy w miescie BEZ obecnego gracza
		{
			if (play != currentPlayer && play->GetPosition() == currentCity)
			{
				supPlayers.push_back(play);
				if (play->GetRole() == ROLE_RESEARCHER)		  //czy dodawany gracz bedzie mogl dawac dowolne karty
				{
					isResearcher = true;
				}
				if (cityCard == nullptr && anotherPlayersCityCard == nullptr) //czy juz ktos SPRAWDZONY wczesniej tej karty nie ma
				{
					anotherPlayersCityCard = play->FindCard(currentCity->GetName());
				}
			}
		}
		if (!supPlayers.empty())
		{
			if (currentPlayer->GetRole() == ROLE_RESEARCHER || cityCard != nullptr)//GIVE_CARD	  luka - brak warunku na karty specjalne...
			{
				decisionsAvailable.push_back(DEC_GIVE_CARD);
			}
			if (isResearcher || anotherPlayersCityCard != nullptr)				   //GAIN_CARD
			{
				decisionsAvailable.push_back(DEC_GAIN_CARD);
			}
		}
		if (currentCity->IsStation())											   //DISCOVER_CURE
		{
			for (Disease dis : diseases)
			{
				cardsInColor.clear();
				for (PlayerCard* card : currentPlayer->SeeCards())
				{
					if (card->GetColor() == dis.getID())
					{
						cardsInColor.push_back(card);
					}
				}
				if (cardsInColor.size() >= 5)
				{
					decisionsAvailable.push_back(DEC_DISCOVER_CURE);
					break;
				}
				else
				{
					if (currentPlayer->GetRole() == ROLE_SCIENTIST && cardsInColor.size() >= 4)
					{
						decisionsAvailable.push_back(DEC_DISCOVER_CURE);
						break;
					}
				}
			}
		}
	}
	for (Player* play : players)
	{
		for (PlayerCard* card : play->SeeCards())								//USE_SPECIAL
		{
			checker = dynamic_cast<SpecialCard*>(card);
			if (checker != nullptr)
			{
				decisionsAvailable.push_back(DEC_USE_SPECIAL);
				break;
			}
		}
		if (checker != nullptr)
		{
			break;
		}
	}
	decisionsAvailable.push_back(DEC_PASS);											//PASS
	return decisionsAvailable;
}

vector<Player*> Board::ChoosePlayer() const
{
	return players;
}

vector<Player*> Board::ChoosePlayerInCity()
{
	return supPlayers;
}

QSet<City*> Board::SeeFREECitiesAsDispatcher(Player* toMove)
{
	QSet<City*> toReturn = ChooseMoveShort(toMove);
	for (Player* play : players)
	{
		if (play != toMove)
		{
			toReturn.insert(play->GetPosition());
		}
	}
	return toReturn;
}

QSet<City*> Board::ChooseMoveShort(Player* toMove)
{
	QSet<City*> toSend;
	for (City* city : toMove->GetPosition()->Neighbours())
	{
		toSend.insert(city);
	}
	if (toMove->GetPosition()->IsStation())
	{
		for (City* city : Stations)
		{
			toSend.insert(city);
		}
	}
	return toSend;
}

QSet<City*> Board::ChooseMoveEverywhere(Player * toMove)
{
	QSet<City*> toReturn;
	City* current = toMove->GetPosition();
	for (City* city : Cities)
	{
		if (city != current)
		{
			toReturn.insert(city);
		}
	}
	return toReturn;
}

vector<DiseaseType> Board::ChooseDiseaseToTreat()
{
	vector<DiseaseType> toChoose;
	for(Disease& dis:diseases)
	{
		if (currentCity->DiseaseCounter(dis.getID()) > 0)
		{
			toChoose.push_back(dis.getID());
		}
	}
	return toChoose;
}

vector<SpecialCard*> Board::ChooseSpecial()
{
	vector<SpecialCard*> specialsToUse;
	for (Player* play : players)
	{
		for (PlayerCard* card : play->SeeCards())
		{
			if (card->GetColor() == UNKNOWN) //bo specjalne maja byc bez koloru	|| uwaga na mozliwy blad - Epidemic na rece !!!
			{
				SpecialCard* special = dynamic_cast<SpecialCard*>(card);
				if (special != nullptr)
				{
					specialsToUse.push_back(special);
				}
				else
				{
					throw string("niby karta jest, ale nie ma !?!?!");
				}				
			}
		}
	}
	return specialsToUse;
}

void Board::MoveToAnotherPlayer(City* target, Player* toMove)
{
	MoveShort(target, toMove);
}

void Board::MoveShort(City * target, Player * toMove) //PAMIETAJ O STACJACH !!!
{
	toMove->MoveToNeighbour(target);//zawiera wewnatrz przeniesienie na ekranie
	if (toMove->GetRole() == ROLE_MEDIC)
	{
		MedicIncoming();
	}
	--movesLeft;
}

void Board::MoveShort(City * target)
{
	MoveShort(target, currentPlayer);
}

void Board::MoveToCard(PlayerCard * card, Player * toMove)
{
	Card* takenCard = toMove->MoveToCard(FindCity(card->GetName()));//zawiera przemieszczenie pionka
	if (takenCard == nullptr) //jak nie karta ruszanego gracza
	{
		takenCard = currentPlayer->Discard(card);//to karta DISPATCHERA
	}
	if (takenCard == nullptr)
	{
		throw string("zgubiona karta !!!"); //krytyczny blad
	}
	playerDiscarded.PutCard(takenCard);
	mediator().moveCard(takenCard, &(this->playerDiscarded));
	if (toMove->GetRole() == ROLE_MEDIC)
	{
		MedicIncoming();
	}
	--movesLeft;
}

void Board::MoveToCard(PlayerCard * card)
{
	MoveToCard(card, currentPlayer);
}

void Board::MoveEverywhere(City * target, Player * toMove)
{
	Card* used = toMove->MoveEverywhere(target);
	if (used == nullptr) //jak nie karta ruszanego gracza
	{
		for (PlayerCard* card : currentPlayer->SeeCards())
		{
			if (card->GetName() == target->GetName())
			{
				used = currentPlayer->Discard(card);//to karta DISPATCHERA
				break;
			}
		}
	}
	if (used == nullptr)
	{
		throw string("zgubiona karta !!!"); //krytyczny blad
	}
	playerDiscarded.PutCard(used);
	mediator().moveCard(used, &(this->playerDiscarded));
	if (toMove->GetRole() == ROLE_MEDIC)
	{
		MedicIncoming();
	}
	--movesLeft;
}

void Board::MoveEverywhere(City * target)
{
	MoveEverywhere(target, currentPlayer);
}

void Board::BuildStation()
{
	Card* usedCard = currentPlayer->BuildStation();
	if (usedCard!=nullptr)
	{
		playerDiscarded.PutCard(usedCard);
	}
	if (stationsLeft > 0)
	{
		--stationsLeft;
        Stations.push_back(currentCity);
        --movesLeft;
        mediator().buildResearchStation(currentCity);
	}
	else
	{
		mediator().chooseStationToRemove(Stations, THISMETHOD(&Board::BuildStationIfFull)); //tak, zapomnialem w mediatorze o przekazywaniu wektora stacji - do zmiany w mediator.h
	}
	Stations.push_back(currentCity);
	--movesLeft;
	mediator().buildResearchStation(currentCity);
}

void Board::BuildStationIfFull(City* c)
{																			//>>>>>>> TUTAJ <<<<<<<<<
    for (vector<City*>::iterator it = Stations.begin(); it != Stations.end(); ++it)
    {
        if ((*it) == c)
        {
            Stations.erase(it);
            c->RemoveResearchStation();
			mediator().removeResearchStation(c);
            break;
        }
    }
	Stations.push_back(currentCity);
	--movesLeft;
	mediator().buildResearchStation(currentCity);
	//currentCity->BuildResearchStation(); // !!! - czy to ma być w kodzie?
}

void Board::Treat(DiseaseType disType)
{
	Disease* dis = FindDisease(disType);
	dis->healDisease(currentCity, currentPlayer->GetRole());
	if (all_of(diseases.begin(), diseases.end(), IsEradicated))
	{
		gameStatus = WON; //zwyciestwo
	}
	--movesLeft;
}

vector<PlayerCard*> Board::ChooseCardToGive(Player* target)
{
	vector<PlayerCard*> toReturn;
	if (currentPlayer->GetRole() == ROLE_RESEARCHER)
	{
		for (PlayerCard* card : currentPlayer->SeeCards())
		{
			if (card->GetColor() != UNKNOWN)
			{
				toReturn.push_back(card);
			}
		}
	}
	else
	{
		toReturn.push_back(currentPlayer->FindCard(currentCity->GetName()));
	}
	return toReturn;
}

vector<PlayerCard*> Board::ChooseCardToGain(Player* source)		
{	 
	vector<PlayerCard*> toReturn;
	if (source->GetRole() == ROLE_RESEARCHER)
	{

		for (PlayerCard* card : source->SeeCards())
		{
			if (card->GetColor() != UNKNOWN)
			{
				toReturn.push_back(card);
			}
		}
	}
	else //obsluga tutaj dla pojedynczej karty
	{
		toReturn.push_back(source->FindCard(currentCity->GetName()));
	} 
	return toReturn;
}

void Board::GiveCard(Player* target, PlayerCard* card)	  //niech GUI pobiera z planszy (Board) liste dostepnych graczy - wybiera gracza || kart
{
	currentPlayer->ShareKnowledge(target, card);
}

void Board::GainCard(Player* source, PlayerCard* card)
{
	currentPlayer->EarnCardFrom(source, card);	//wewnatrz jest przekazanie karty na ekranie
}

void Board::QuietNight()
{					  	
	SpecialCardType  number = SC_ONE_QUIET_NIGHT;
	DiscardSpecialCard(SpecialCardType_SL[number].toStdString());
	skipInfecting = true;
}
vector<Card*> Board::Forecast()
{
	SpecialCardType  number = SC_FORECAST;
	DiscardSpecialCard(SpecialCardType_SL[number].toStdString());
	vector<Card*> topCards;
	for (int i = 0; i < 6; ++i)
	{
		topCards.push_back(diseasesNew.takeCard());
	}
	return topCards;
/*
	mediator().seeTopDiseaseDeck(6);*/
}

void Board::Forecast(vector<Card*> returned)
{
	for (int i = 0; i < returned.size(); ++i)
	{
		diseasesNew.PutCard(returned[i]);
	}	 
}

vector<Card*> Board::ResilientPopulation()
{
	return vector<Card*>(diseasesDiscarded.SeeDeck());
}

void Board::ResilientPopulation(Card* toRemove)
{
	SpecialCardType number = SC_RESILIENT_POPULATION;
	DiscardSpecialCard(SpecialCardType_SL[number].toStdString());
	diseasesDiscarded.RemoveCard(toRemove);
}

void Board::Airlift(Player* toMove, City* target)
{
	SpecialCardType  number = SC_AIRLIFT;
	DiscardSpecialCard(SpecialCardType_SL[number].toStdString());
	toMove->MoveToNeighbour(target);   //bo tylko ta nie usunie karty z reki
}
void Board::GovernmentGrant(City* toBuild)
{
	SpecialCardType  number = SC_GOVERNMENT_GRANT;
	DiscardSpecialCard(SpecialCardType_SL[number].toStdString());
	toBuild->BuildResearchStation();
	Stations.push_back(toBuild);
	if (stationsLeft > 0)
	{
		--stationsLeft;
	}
	else
	{
		mediator().chooseStationToRemove(Stations, THISMETHOD(&Board::BuildStationIfFull)); //tak, zapomnialem w mediatorze o przekazywaniu wektora stacji - do zmiany w mediator.h
	}
	mediator().buildResearchStation(currentCity);
}

//void Board::PlayerTurn(Decision decide)
//{
//	currentPlayer = players[currentPlayerNumber%players.size()]; //do kopiowania, gdzie bedzie currentPlayer
//	switch (decide)
//	{
//	case DEC_MOVE_ANOTHER:
//		decisionsAvailable.push_back(DEC_MOVE_SHORT);
//
//		break;
//	case DEC_MOVE_SHORT:
//		cout << currentCity->Neighbours();
//		break;
//	case DEC_MOVE_TO_CARD:
//		cout << currentPlayer->SeeCards();
//		break;
//	case DEC_MOVE_EVERYWHERE:
//		cout << Cities;
//		break;
//	case DEC_BUILD_STATION:
//		playerDiscarded.PutCard(currentPlayer->BuildStation());
//		if (stationsLeft > 0)
//		{
//			--stationsLeft;
//			Stations.push_back(currentCity);
//		}
//		else
//		{
//			City* c;
//			cout << Stations;
//			for (vector<City*>::iterator it = Stations.begin(); it != Stations.end(); ++it)
//			{
//				if ((*it) == c)
//				{
//					Stations.erase(it);
//				}
//			}
//			mediator().removeResearchStation(c);
//		}
//		--movesLeft;
//		mediator().buildResearchStation(currentCity);
//		break;
//	case DEC_DISCOVER_CURE:
//		cout << cardsInColor;
//		break;
//	case DEC_TREAT:
//	{
//		vector<Disease&> disInCity;
//		for (Disease& dis : diseases)
//		{
//			if (currentCity->DiseaseCounter(dis.getID()) > 0)
//			{
//				disInCity.push_back(dis);
//			}
//		}
//		if (disInCity.size() == 1)
//		{
//			disInCity[0].healDisease(currentCity, currentPlayer->GetRole());
//			--movesLeft;
//		}
//		else
//		{
//			cout << disInCity;
//		}
//		break;
//	}
//	case DEC_GAIN_CARD:
//		if (isResearcher)
//		{
//			for (Player* play : supPlayers)
//			{
//				if (play->GetRole() == ROLE_RESEARCHER)
//				{
//					cout << play->SeeCards();
//					break;
//				}
//			}
//		}
//		else	 //anotherPlayersCityCard != nullptr)
//		{
//			for (Player* play : supPlayers)
//			{
//				for (PlayerCard* card : play->SeeCards())
//				{
//					if (card == anotherPlayersCityCard)
//					{
//						play->ShareKnowledge(currentPlayer, card);
//						--movesLeft;
//						break;
//					}
//				}
//			}
//		}
//		break;
//	case DEC_GIVE_CARD:
//		if (currentPlayer->GetRole() == ROLE_RESEARCHER)
//		{
//			cout << currentPlayer->SeeCards();
//			cout << supPlayers;
//		}
//		else	 //anotherPlayersCityCard != nullptr)
//		{
//			for (Player* play : supPlayers)
//			{
//				for (PlayerCard* card : play->SeeCards())
//				{
//					if (card == anotherPlayersCityCard)
//					{
//						play->ShareKnowledge(currentPlayer, card);
//						--movesLeft;
//						break;
//					}
//				}
//			}
//		}
//		break;
//	case DEC_USE_SPECIAL:
//		break;
//	case DEC_PASS:
//		break;
//	default:
//		break;
//	}
//}

//int Board::PlayerTurn(Player* currentPlayer)
//{
//	int decision,j = 4;
//	vector<Decision> decide;
//	while (j>=0)
//	{
//		if (j > 0)
//		{
//MONDELUZ 72 - KREDKI (KOH-I-NOOR HARDTMUTH
//		}
//		else
//		{
//			for (PlayerCard* card : currentPlayer->SeeCards())
//			{
//				if (typeid(card).name() == typeid(SpecialCard*).name())
//				{
//					decide.push_back(DEC_USE_SPECIAL);
//					break;
//				}
//			}
//			decide.push_back(DEC_PASS);
//		}
//				cout << "czego gracz oczekuje - co chce zrobic?" << endl; //zwroc ENUM
//		//STEROWANIE w GUI
//		cin >> decision;
//		decide = (Decision)decision;
//		switch (decide)
//		{
//		case DEC_MOVE_ANOTHER:
//			if (currentPlayer->GetRole() == ROLE_DISPATCHER)
//			{
//				Player* playerToMove;
//						cout << "Podaj gracza do przesuniecia..." << endl;
//						cout << "Podaj sposob ruchu (0-3)" << endl;
//						cin >> decision;
//				decide = (Decision)decision;
//				switch (decide)
//				{
//				case DEC_MOVE_SHORT:
//					cout << "Miasta dostepne: " << endl;
//					playerToMove->GetPosition()->Neighbours(); //jako ARGUMENT (vector<City*>)
//					playerToMove->MoveToNeighbour(/*WYNIK WYWOLANEJ FUNKCJI*/);
//					--j;
//					if (playerToMove->GetRole() == ROLE_MEDIC)
//					{
//						MedicIncoming(playerToMove);
//					}
//					break;
//				case DEC_MOVE_TO_CARD:
//					.
//					--j;
//					if (playerToMove->GetRole() == ROLE_MEDIC)
//					{
//						MedicIncoming(playerToMove);
//					}
//					break;
//				case DEC_MOVE_EVERYWHERE:
//					.
//					--j;
//					if (playerToMove->GetRole() == ROLE_MEDIC)
//					{
//						MedicIncoming(playerToMove);
//					}
//					break;
//				}
//			}
//			else
//			{
//				cout << "no debil...";
//			}
//			break;
//		case DEC_MOVE_SHORT:
//		{
//			vector<City*> citiesToMove;
//			City* position = currentPlayer->GetPosition();
//					cout << "Miasta dostepne: " << endl;
//			.
//			citiesToMove = position->Neighbours();
//			if (position->IsStation())
//			{
//				for (City* city : Stations)
//				{
//					if (city != position)
//					{
//						citiesToMove.push_back(city);
//					}
//				}
//			}
//					cout << "OTO LISTA MIAST DO RUCHU: " << citiesToMove << endl;
//			currentPlayer->MoveToNeighbour(/*WYNIK WYWOLANEJ FUNKCJI*/);
//			--j;
//			if (currentPlayer->GetRole() == ROLE_MEDIC)
//			{
//				MedicIncoming(currentPlayer);
//			}
//			break;
//		}
//		case DEC_MOVE_TO_CARD:
//		{
//					cout << "Podaj karte - miasto" << endl;
//			.
//				currentPlayer->SeeCards(); //JAKO ARGUMENT (vector<Card*>)
//			Card* card; //PRZYPISAC WYNIK
//			if (card->GetName() == currentPlayer->GetPosition()->GetName())
//			{
//					cout << "debil... po co sie pozbywac karty w ten sposob?" << endl;
//			}
//			else
//			{
//				City* destinationCity = FindCity(card->GetName());
//				currentPlayer->MoveToCard(destinationCity);
//				--j;
//				if (currentPlayer->GetRole() == ROLE_MEDIC)
//				{
//					MedicIncoming(currentPlayer);
//				}
//			}
//			break;
//		}
//		case DEC_MOVE_EVERYWHERE:
//		{
//			Card* card = currentPlayer->FindCard(currentPlayer->GetPosition()->GetName());
//			if (card != nullptr)
//			{
//				.
//				City* destination; // przypisac wynik zapytania do uzytkownika
//				currentPlayer->MoveEverywhere(destination);
//				--j;
//				if (currentPlayer->GetRole() == ROLE_MEDIC)
//				{
//					MedicIncoming(currentPlayer);
//				}
//			}
//			else
//			{
//					cout << "nie masz karty do wykonania tego ruchu" << endl;
//			}
//			break;
//		}
//		case DEC_BUILD_STATION:
//			if (!(currentPlayer->GetPosition()->IsStation()))
//			{
//				if (currentPlayer->GetRole() == ROLE_OPERATIONSEXPERT)
//				{
//					currentPlayer->GetPosition()->BuildResearchStation();
//					--j;
//				}
//				else
//				{
//					PlayerCard* card = currentPlayer->FindCard(currentPlayer->GetPosition()->GetName());
//					if (card != nullptr)
//					{
//						currentPlayer->GetPosition()->BuildResearchStation();
//						currentPlayer->Discard(card); //bez ponownego przypisania wyniku - karte przeciez juz trzymam wskaznikiem
//						playerDiscarded.PutCard(card);
//						--j;
//					}
//					else
//					{
//						cout << "BRAK KARTY";
//					}
//				}
//			}
//			else
//			{
//				cout << "Juz tu jest stacja..." << endl;
//			}
//			break;
//		case DEC_DISCOVER_CURE:
//			if (FindDisease(currentPlayer->GetPosition()->GetColor())->Status() == NEW)
//			{
//				vector<PlayerCard*> cardsInProperColor = currentPlayer->ChooseInColorCards(currentPlayer->GetPosition()->GetColor());
//				if (currentPlayer->GetRole() == ROLE_SCIENTIST && cardsInProperColor.size() >= 4)
//				{
//					cout << "ktore karty wybierasz?" << endl;		//argumentem - cardsInProperColor || zwracac ma wybrane karty
//					.
//					currentPlayer->Discard(cardsInProperColor);
//					for (PlayerCard* card : cardsInProperColor)
//					{
//						playerDiscarded.PutCard(card);
//					}
//					--j;
//				}
//				else
//					if (cardsInProperColor.size() >= 5)
//					{	//kopia z powyzej... !!!
//						cout << "ktore karty wybierasz?" << endl;		//argumentem - cardsInProperColor || zwracac ma wybrane karty
//						.
//							currentPlayer->Discard(cardsInProperColor);
//						for (PlayerCard* card : cardsInProperColor)
//						{
//							playerDiscarded.PutCard(card);
//						}
//						--j;
//					}
//					else
//					{
//						cout << "Nie masz wystarczajacej ilosci kart..." << endl;
//					}
//			}
//			else
//			{
//				cout << "no debil... juz masz lek na ten kolor!!!" << endl;
//			}
//			break;
//		case DEC_TREAT:
//
//
//			--j;
//			break;
//		case DEC_GAIN_CARD:
//
//			--j;
//			break;
//		case DEC_GIVE_CARD:
//
//			--j;
//			break;
//		case DEC_USE_SPECIAL:
//			break;
//		case DEC_PASS:
//			j = 0;
//			break;
//		}
//		if (all_of(diseases.begin(), diseases.end(), IsEradicated))
//		{
//			return 1; //zwyciestwo
//		}
//		//albo TUTAJ
//	}
//	//for (int i = 4; i > 0; --i)
//	//{
//	//		//TUTAJ WPISAC PRZEBIEG TURY gracza
//	//}
//	return 0;
//}

////void Board::Engine()
//{
//	int gameStatus = 0, i = 0;
//	Card* card;
//	EpidemicCard* eCard;
//	bool skipInfecting;
//	try
//	{
//		while (gameStatus == 0)
//		{
//			skipInfecting = false;
//			gameStatus = PlayerTurn(players[i%players.size()]);
//			for (int j = 0; j < 2; ++j)
//			{
//				card = playerNew.takeCard();
//				if (typeid(card).name() == typeid(EpidemicCard*).name()) //bo trzeba RTTI uzyc (a juz mialem wywalic)
//				{
//					eCard = dynamic_cast<EpidemicCard*>(card); //ZBEDNE (nieuzywane, ale RTTI)
//					Card* dCard = diseasesNew.TakeBottom();
//					Infect(dCard, 3);							//na podstawie karty zajmuje sie calym procesem infekowania
//					diseasesNew.Rethrow(&diseasesDiscarded);
//					//eCard->Epidemy(diseasesNew, diseasesDiscarded);
//					playerDiscarded.PutCard(card);
//				}
//				else
//				{
//					(players[i%players.size()])->EarnCard((PlayerCard*) card); // czy nie pomyli danych o karcie przez rzutowanie??
//				}
//			}
//			//guzik zatwierdzania konca tury - obsluga				ew. ZMIANA skipInfecting !!!
//			PlayTheInfection(skipInfecting); //ROZSZERZ CHOROBY
//			++i;
//		}
//	}
//	catch (out_of_range except) //moze rzucac tez wartosc - typ przegranej?
//	{
//		gameStatus = -1;
//	}
//	catch (string error)
//	{
//		gameStatus = -2;
//	}
//	if (gameStatus<0)
//	{
//		cout << "PORAZKA" << endl;
//	}
//	else
//	{
//		cout << "Wygrana !!!" << endl;
//	}
//}

//KONSTRUKCJA:
Board::Board(Difficulty difficulty, QVector<QPair<QString, PlayerRole>> players)
{
    mediator().setEngine(this);
	diseases.push_back(Disease("BLUE"));
	diseases.push_back(Disease("YELLOW"));
	diseases.push_back(Disease("BLACK"));
	diseases.push_back(Disease("RED"));
	diseasesNew.prepare("DiseaseDeck.txt", (int)difficulty);
	playerNew.prepare("PlayerDeck.txt", (int)difficulty);
	outbreaksMarker = 0;
	gameStatus = IN_PROGRESS;
	skipInfecting = false;
	infectionRateMarker = { 1, 2, 2, 2, 3, 3, 4, 4 }; //pierwszy wskazuje, ktory element obecnie brac !!!

	prepareCityList();

	City* cityPtr = FindCity("Atlanta");
	cityPtr->BuildResearchStation();
	Stations.push_back(cityPtr);
	stationsLeft = 5;
	srand(time(NULL));
	for (QPair<QString, PlayerRole> onePlayer : players)
	{
		if (onePlayer.second == ROLE_RANDOM)
		{
			PlayerRole role;
			bool isUnique = true;
			do
			{
				role = static_cast<PlayerRole>((rand() % 5) + 1);	   //<0;4> + 1
				isUnique = true;
				for (Player* play : this->players)
				{
					if (play->GetRole() == role)
					{
						isUnique = false;
						break;
					}
				}
			} while (!isUnique);
		}
		this->players.push_back(new Player(onePlayer.second, onePlayer.first.toStdString(), cityPtr));
	}
	int playersCount = this->players.size();
	for (Player* play : this->players)
	{
		for (int i = 9 / playersCount; i > 0; --i)
		{
			play->EarnCard((PlayerCard*)playerNew.takeCard());
		}
	}
	//GRACZE NA EKRAN, NA Atlante
	PrepareDiseases();
	currentPlayerNumber = 0;
}

void Board::prepareCityList()
{
	fstream File("Cities.txt", ios::in); // |ios::binary
	if (!File.is_open())
		throw "dupa in opening the FILE cities";

	int cityCounter, neighbourCounter;
	string ccityControl, cityName, neighbours, cityColor;
	QString colour;
	map<City*, vector<string>> citiesWithNeighbourhood;
	vector<string> neighboursForCities;

	File >> cityCounter;
	getline(File, ccityControl);
	for (int i = 0; i < cityCounter; i++)
	{
		getline(File, ccityControl);
		if (ccityControl == "CCity")
		{
			getline(File, cityName);
			getline(File, cityColor);
			File >> neighbourCounter;
			getline(File, neighbours);	//przesun do nowej linii w pliku
			for (int i = 0; i < neighbourCounter; ++i)
			{
				getline(File, neighbours);
				neighboursForCities.push_back(neighbours);
			}
			colour.fromStdString(cityColor);
			citiesWithNeighbourhood[new City(cityName, (DiseaseType)DiseaseType_SL.indexOf(colour))] = neighboursForCities;
		}
	}
	Cities = City::AddNeighbours(citiesWithNeighbourhood);
}

void Board::PrepareDiseases()
{
	for (int j = 3; j > 0; --j)
	{
		for (int i = 0; i < 3; ++i)
		{
			Infect(diseasesNew.takeCard(), j);
		}
	}
}

Board::~Board()
{
	for (City* city : Cities)
	{
		delete city;
	}
	for (Player* player : players)
	{
		delete player;
	}
}

GameResult Board::GameStatus() const
{
	return gameStatus;
}